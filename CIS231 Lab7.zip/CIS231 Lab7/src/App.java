public class App {
    public App() {
        MyList<String> list = new MyLinkedList<>();

        // Test adding elements
        System.out.println("Adding elements: AAAA, BBBB, CCCC, DDDD, EEEE");
        list.add("AAAA");
        list.add("BBBB");
        list.add("CCCC");
        list.add("DDDD");
        list.add("EEEE");
        System.out.println("List size: " + list.size());
        displayList(list);

        // Test inserting at index
        System.out.println("Inserting FFFF at index 2");
        list.add(2, "FFFF");
        displayList(list);

        // Test removing by index
        System.out.println("Removing element at index 0");
        list.remove(0);
        displayList(list);

        // Test setting a new value
        System.out.println("Setting GGGG at index 1");
        list.set(1, "GGGG");
        displayList(list);

        // Check if list contains a certain element
        String checkString = "CCCC";
        System.out.println("Checking if list contains " + checkString + ": " + list.contains(checkString));

        // Get index of a certain element
        System.out.println("Index of GGGG: " + list.indexOf("GGGG"));

        // Empty the list and display size
        System.out.println("Clearing list...");
        list.removeAll();
        System.out.println("List size after clearing: " + list.size());
    }

    private <T> void displayList(MyList<T> list) {
        System.out.println("List contents:");
        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i) + " ");
        }
        System.out.println("\n");
    }

    public static void main(String[] args) {
        new App();
    }
}
