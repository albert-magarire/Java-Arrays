import java.util.NoSuchElementException;

public class MyLinkedList<T> implements MyList<T> {
    private Node<T> head;
    private int size;

    public MyLinkedList() {
        this.head = null;
        this.size = 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public T get(int index) {
        validateIndex(index);
        Node<T> current = head;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        return current.data;
    }

    @Override
    public void add(T obj) {
        if (head == null) {
            head = new Node<>(obj);
        } else {
            Node<T> current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = new Node<>(obj);
        }
        size++;
    }

    @Override
    public void add(int index, T obj) {
        validateIndexForAdd(index);
        if (index == 0) {
            Node<T> newNode = new Node<>(obj);
            newNode.next = head;
            head = newNode;
        } else {
            Node<T> current = head;
            for (int i = 0; i < index - 1; i++) {
                current = current.next;
            }
            Node<T> newNode = new Node<>(obj);
            newNode.next = current.next;
            current.next = newNode;
        }
        size++;
    }

    @Override
    public void remove(int index) {
        validateIndex(index);
        if (index == 0) {
            head = head.next;
        } else {
            Node<T> current = head;
            for (int i = 0; i < index - 1; i++) {
                current = current.next;
            }
            current.next = current.next.next;
        }
        size--;
    }

    @Override
    public void remove(T obj) {
        if (isEmpty()) throw new NoSuchElementException("List is empty.");

        if (head.data.equals(obj)) {
            head = head.next;
            size--;
            return;
        }

        Node<T> current = head;
        while (current.next != null && !current.next.data.equals(obj)) {
            current = current.next;
        }

        if (current.next == null) {
            throw new NoSuchElementException("Element not found.");
        } else {
            current.next = current.next.next;
            size--;
        }
    }

    @Override
    public void set(int index, T obj) {
        validateIndex(index);
        Node<T> current = head;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        current.data = obj;
    }

    @Override
    public boolean contains(T obj) {
        Node<T> current = head;
        while (current != null) {
            if (current.data.equals(obj)) return true;
            current = current.next;
        }
        return false;
    }

    @Override
    public int indexOf(T obj) {
        Node<T> current = head;
        int index = 0;
        while (current != null) {
            if (current.data.equals(obj)) return index;
            current = current.next;
            index++;
        }
        return -1;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public void removeAll() {
        head = null;
        size = 0;
    }

    private void validateIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
    }

    private void validateIndexForAdd(int index) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
    }
}
