public interface MyList<T> {
    int size();  // for size of the list.
    T get(int index);  // element at a given index.
    void add(T obj);  // Adds an object to end of list.
    void add(int index, T obj);  // Inserts object at specified index.
    void remove(int index);  // Removes the object at specified index.
    void remove(T obj);  // Removes first occurrence of object.
    void set(int index, T obj);  // Replaces the element at specified index.
    boolean contains(T obj);  // Checks if list contains object.
    int indexOf(T obj);  // Finds index of the first occurrence of the object.
    boolean isEmpty();  // Checks if the list is empty.
    void removeAll();  // Clears the list.
}
